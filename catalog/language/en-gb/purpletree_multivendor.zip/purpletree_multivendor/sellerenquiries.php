<?php
$_['text_store']         	 = 'Seller Enquiries';
$_['entry_message']      	 = 'Message';
$_['button_save']			 = 'Send';
$_['error_enquiry']          = 'Message must be greater than zero';
$_['text_success']           = 'Message send successfully!';
$_['text_store']         	 = 'Admin Messages';
$_['heading_title']          = 'Admin Messages';
$_['entry_messages']      	 = 'Messages';