<?php

$_['error_license']              = 'Invalid License of Purpletree Multivendor';

?>