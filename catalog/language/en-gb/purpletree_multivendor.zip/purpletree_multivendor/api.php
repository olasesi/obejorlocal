<?php
// Heading
$_['error_permission']          = 'Permission Error. Check API credentials';
$_['seller_not_logged']         = 'Seller Not Logged In';
$_['seller_not_approved']       = 'Seller Not Approved';
$_['error_license']         	= 'Invalid License';
$_['no_data']         			= 'No Data';
$_['seller_order_not_found']    = "seller id and order id not found";
$_['product_limit_error']    = "Product Limit Error";
$_['register_success']    = "Customer Register Successfully";
$_['already_logged']    = "Customer already Login";
$_['seller_register_succ']    = "Seller Register Successfully";