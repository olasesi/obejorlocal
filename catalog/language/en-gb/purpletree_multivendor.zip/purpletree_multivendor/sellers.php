<?php
// Text
$_['text_heading'] 		= 'Sellers';
$_['text_refine']       = 'Search';
$_['text_product']      = 'Products';
$_['text_sellercontact']= 'Contact seller';
$_['text_empty']        = 'There are no sellers for listing.';
$_['text_sort']         = 'Sort By:';
$_['text_name_asc']     = 'Name (A - Z)';
$_['text_name_desc']    = 'Name (Z - A)';
$_['text_limit']        = 'Show:';