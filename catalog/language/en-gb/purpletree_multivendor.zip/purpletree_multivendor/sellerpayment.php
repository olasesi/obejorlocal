<?php 
$_['heading_title']		= 'Payments';

//text
$_['text_payment']		= 'Payments';
$_['text_trnasaction']		= 'Transacton Id';
$_['text_amount']		= 'Amount';
$_['text_payment_mode']		= 'Payment Mode';
$_['text_status']		= 'Status';
$_['text_created_at']		= 'Created Date';
$_['text_empty']		= 'You do not have any payments!';

$_['entry_date_from']          = 'Date From';
$_['entry_date_to']          = 'Date To';

$_['button_filter'] = 'Filter';
?>